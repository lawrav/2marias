# LightControl
This repository contains Arduino files for controlling a series of relays automatically according to the frequency of music, as well as manually. The relays for this project controlled a series of Christmas lights to create a Christmas in July light show!

Light show video: https://www.youtube.com/watch?v=Ii-aXG2eg7o

How to make a light show video: https://www.youtube.com/watch?v=P9BNTpvb7o0
